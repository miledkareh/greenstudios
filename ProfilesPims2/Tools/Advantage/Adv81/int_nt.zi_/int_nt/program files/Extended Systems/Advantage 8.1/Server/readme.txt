README.TXT Advantage Database Server for Windows NT/2000/2003  8.1
========== ==================================================  ===

Thank you for purchasing Advantage Database Server for Windows
NT/2000/2003. In order to provide you with as much information as
possible about Advantage, this README.TXT file contains information
about the Advantage Database Server for Windows NT/2000/2003 that may
not be in the Advantage Help file: specific compatibility issues,
release level information, etc.


Contents:
==========
1. Effects of Upgrading
2. Effects of Upgrading from a Version Prior to v8.0
3. Important Notes
4. What's New in v8.1
5. What's New in v8.0
6. Known Problems


1. Effects of Upgrading
========================

The following Advantage functionality changes may affect your
applications if you upgrade to version 8.1 of the Advantage
Database Server.

*  The CREATE DATABASE statement can now only be called by the
   ADSSYS user when executed on a dictionary connection.

*  Support for the Numeric field type was added to the proprietary
   Advantage ADT table format.  This can affect your application if it
   creates ADT tables using the Numeric field specification either
   though SQL or through the AdsCreateTable API.  In older versions of
   Advantage, a Numeric field specification for an ADT would result in a
   short integer, long integer, or floating point field type being
   created depending on the precision and scale of the specification.
   Beginning with v8.1, the Numeric field specification will result in a
   Numeric field.  It is important to note that the size in the field
   specification refers to the total length of the field.  This is the
   same as with DBF tables, however with ADT tables, Advantage reserves
   one byte for the sign even for positive integers.  For example,
   creating a table through SQL with the definition "num Numeric(2,0)"
   will produce a two byte numeric field with no decimal places.  If it
   is in a DBF table, the range of values that can be stored in it is -9
   to 99.  With ADTs, the maximum precision is the same for both
   positive and negative numbers.  The range of values that can be
   stored is -9 to 9 for this two byte field.

*  SQL queries which use the TOP limiter on UNION-ed statements may
   return different result sets.  This is due to the new support for
   TOP on subqueries.  For example, the statement SELECT TOP 1 * FROM
   table1 UNION ALL SELECT * FROM table2 in the past would only
   return one record.  Moving forward, the same query will return one
   record from the first SELECT statement, plus all records from the
   second SELECT statement.  To apply the TOP 1 to the entire result
   set and achieve the same result as in the past, a statement of the
   following form can be used: SELECT TOP 1 * FROM (SELECT * FROM
   table1 UNION ALL SELECT * FROM table2)

*  Three new reserved SQL keywords have been introduced: FUNCTION,
   RETURN and RETURNS.  If existing SQL statements use any of these
   keywords as column or table identifiers, they will need to be
   enclosed in double quotes or square brackets.

*  Static cursors that use DBF tables as base tables may now use the
   "Numeric" column type in place of Double or Integer.  The Numeric
   field type is supported by the ADT table type now and the static
   cursor no longer maps DBF numeric field types into ADT double or
   Integer fields.

*  Integer division expressions now follow the SQL standard of
   returning results as an integer data type.  The fractional portion
   will be truncated.

*  Routines that manage trigger metadata, including trigger deletion,
   have been modified.  If you use any of the following functions or
   canned procedures, read the function/procedure specific help page
   for details on identifying the trigger:
     - AdsDDRemoveTrigger
     - DROP TRIGGER
     - sp_RenameDDObject
     - AdsDDRenameObject
     - AdsDDGetTriggerProperty
     - TAdsDictionary.GetTriggerNames
     - TAdsDictionary.GetTriggerProperty
     - TAdsDictionary.RemoveTrigger
   These functions and procedures will still work when used on
   existing triggers in a database.  If, however, new triggers are
   created, or if triggers are modified (via ARC, or by dropping and
   re-creating them), 5132 (object not found) errors will be returned.
   The trigger name now has to be qualified with a table name.  See the
   function/ procedure specific help file page for details on the
   qualifier format.

*  Adding a new trigger to an existing database created by versions
   of Advantage older than 8.1 (or modifying trigger properties in
   Advantage Data Architect) will cause an internal database version
   update. This update will prevent pre-8.1 servers from opening the
   database.

*  Version 1 AEPs are effectively obsolete with this release.  If you
   must use a version 1 AEP, there are now some limitations.  1) You
   must use AdsOpenTable to open the input and output parameter
   tables and pass ADS_TEMP_CURSOR_TABLE as the ulOptions flag.  2)
   If the AEP is called from Advantage Database Server, you cannot
   open the input and output parameter tables with Advantage Local
   Server.

*  Script triggers now cache their statement handles.  This means if
   a trigger modifies tables other than the table it is defined on,
   those tables will be held open until the table the trigger is
   defined on is closed.  This behavior could cause 7008 or other
   open errors if attempts are made to gain exclusive access to the
   tables referenced by the trigger.

*  The Microsoft ODBC 2.0 escape syntax:
   --(*vendor(Microsoft), product(ODBC) extension *)--
   is no longer supported. The shorthand form { extension } is still
   supported.

*  A 3015, 5012 or 5066 error may be returned if a client with a
   version less than 8.1 restructures an ADT table (using the
   AdsRestructureTable API or an SQL ALTER TABLE statement) and adds a
   Numeric field to the table.

*  An issue where the AdsZapTable API and the sp_ZapTable canned
   procedure were allowed to be called by users who only had update or
   insert permissions on a table was fixed. Users now have to
   explicitly have the delete permission to zap a table.


2. Effects of Upgrading from a Version Prior to v8.0
=====================================================

In addition to the effects of upgrading from version 8.0 of the
Advantage Database Server mentioned in the section above, the
following Advantage functionality changes may affect your applications
if you upgrade to version 8.1 of the Advantage Database Server
from a version of the Advantage Database Server prior to v8.0.

*  Changed behavior of AFTER triggers.  AFTER triggers that modify the
   base table they are defined upon will no longer cause a recursive
   call to the trigger.

*  More specific error codes (7123, 7124) for table corruption may be
   returned in place of the generic 7016 error code.

*  The management APIs (AdsMg* functions) now return the JDBC client
   IP address in the aucUserName structure member and the client
   username in the aucOSUserLoginName structure member.

*  In rare cases, the new DLL caching solution for Advantage Extended
   Procedure (AEP) and trigger containers may decrease AEP and
   trigger performance.  Also, AEP state information not handled by
   the Startup & Shutdown functions may be lost when updating AEP
   containers while they are in use.  A new dictionary property
   (ADS_DD_DISABLE_DLL_CACHING) is available to disable DLL caching.

*  The behavior of using parameters in SQL scripts has changed.  In
   previous releases, all SQL statements in a script were required to
   have an identical number of parameters with identical types, and
   the number of parameters supplied for the execution had to match
   the number of parameters in each SQL statement in the script.  For
   example, given the script: UPDATE customer SET name = ?  WHERE id = ?;
   UPDATE customer SET name = ?  WHERE id = ?; Only two parameters could
   be supplied to execute the script.  The two parameters would be
   applied to both statements.  In Advantage v8.0 and greater, all
   parameters in the SQL script are independent of each other.  The
   above sample SQL script will require four parameters to execute.
   Advantage v8.0 and greater also allows the following sample script
   that is not allowed in the previous version due to the different
   number of parameters in the two statements:
   UPDATE customer SET name = ?  WHERE id = 1; SELECT * FROM customer
   WHERE id = 1;

*  The behavior of SQL scripts has changed when the last statement in
   the script is a "SELECT ...  " statement.  In previous versions,
   no cursor is ever returned after executing an SQL script.  In
   Advantage v8.0 and greater, a cursor is returned if the last
   statement in the script is a "SELECT ..." statement.  The returned
   cursor must be closed before the statement handle can be used to
   execute another SQL query.

*  Outer references in subselect queries in INSERT statements are no
   longer allowed.  For example, this SQL statement is no longer
   allowed in Advantage 8.0 and greater:
      INSERT INTO customers1 SELECT lastname, empid
      FROM customers2 WHERE customers1.empid = customers2.empid

*  The following are new SQL reserved keywords: CLOSE, CURSOR,
   DECLARE, ESCAPE, FETCH, FOR, FULL, OF, OPEN, RIGHT, SAVEPOINT.
   If your existing application has SQL statements that use any of
   these reserved keywords as column names or table names, they must
   be delimited with double quotes or square brackets in Advantage
   v8.0 and greater to avoid an error being returned.

*  The AVG aggregate function in SQL now conforms to the SQL standard
   in regard to the data type, precision, and scale of the resulting
   column.  In previous releases, the AVG aggregate function always
   resulted in a column with the DOUBLE data type.  In Advantage
   v8.0 and greater, the resulting column will have the same data type,
   precision, and scale as the column or expression specified in the
   AVG aggregate.  If your application uses the AVG aggregate on an
   integer expression and expects the result to be a DOUBLE, you will
   need to change the SQL statement to explicitly cast the expression
   into a DOUBLE, i.e.  AVG( CAST( int_column AS SQL_DOUBLE )).  If
   the integer expression is not cast into a DOUBLE, any fractional
   value from calculating the average will be truncated.

*  The count of the number of rows modified by an SQL script may be
   different from previous versions. In version 8.0 and newer, the
   cumulative number of rows modified by DML statements will be
   returned.

*  Attempts to open tables in nonexistent directories will now return
   7041 errors.  Previous versions would return 7008 errors for this
   condition.

*  The Advantage Optimized Filter (AOF) engine no longer optimizes on
   ADI composite (multi-segment) indexes that are combined with the +
   (plus) operator.  Version 7.0.0.X and earlier would incorrectly use
   composite ADI indexes that used the + operator for optimization.  The
   + operator results in the entire expression being NULL if either
   operand is NULL (standard SQL processing).  When creating composite
   ADI indexes, you should use the semicolon (;) operator.  For example,
   instead of the index expression "lastname+firstname", you should use
   "lastname;firstname".

*  The constant ADS_MAX_KEY_LENGTH that is found in various header files
   including ace.h, ace.pas, and ace32.bas has been increased from 256
   to 4082.  This may affect the size of structures, stack usage, etc.
   if you have used this constant in your application.

*  The error code returned from performing a data dictionary related
   operation may be different from previous versions.  Specifically, in
   previous releases, the error code 5176 (AE_ILLEGAL_USER_OPERATION)
   was returned when performing an operation that required connecting to
   the database as the ADSSYS user.  Now, the same operation may
   return the error code 5054 (AE_PERMISSION_DENIED).

*  To support new permissions features in the data dictionary, the
   internal version of the data dictionary is now automatically upgraded
   when a new permission is granted or revoked.  The new version of the
   data dictionary is not compatible with older servers.  In other
   words, the newer version of the data dictionary cannot be used on pre
   7.1 versions of ADS or ALS.  However, older client applications
   should still work without problem with the newer version of the data
   dictionary if the application is run against version 7.1 or greater
   of Advantage.  The exception in this situation is that the old client
   application cannot connect as the ADSSYS user.

*  Some properties in the data dictionary that used to be readable by
   any non-adssys user are now available only to users with additional
   permissions granted to them.  An AE_PERMISSION_DENIED error is
   returned when the user does not have permissions to read those
   properties.

*  The '#' character, when used in SQL statements as the leading
   character of a table name, now denotes the usage of a temporary
   table in the context of the current connection.  Existing
   applications that use the '#' character as the leading character of
   any table name in SQL statements may need to be modified to delimit
   the affected table name inside double quotes.

*  When using the data dictionary, the user group name "PUBLIC" is now
   reserved for future use.  Attempts to create a new user group named
   "PUBLIC" will fail with a 5132 (AE_INVALID_OBJECT_NAME) error code.
   Existing user groups in the data dictionary with this name will not
   be affected.

*  System table string fields are now case insensitive fields. System
   tables are tables like system.indexes, system.columns, etc.

*  Fail tables used when manipulating a dictionary must be located on
   the server when using a remote server connection.  This affects
   record level, field level, and RI validation fail tables. When
   providing these table paths, you must now specify a path to the
   remote server, not a local path to the current workstation.

*  With the addition of new permissions (ALTER and DROP), the
   definition of ADS_PERMISSION_ALL has changed to include these new
   permission values.


3. Important Notes
============================

*  For best performance, the Windows NT/2000/2003 server running the
   Advantage Database Server should be configured so that foreground
   applications have NO performance boost. If foreground applications
   are given a performance boost, it is possible for the Advantage
   Database Server to "starve" and provide poor performance. With
   Windows NT/2000/2003, turn off foreground application performance
   boost by double-clicking the "System" icon in the control panel
   folder. With Windows NT 4.0, click on the "Performance" tab. With
   Windows 2000/2003, click on the "Advanced" tab and click the
   "Performance Options" button.

*  Advantage client to Advantage Database Server backwards
   compatibility is supported. Thus, the latest Advantage Database
   Server NT/2000/2003 Service can be running on your Windows
   NT/2000/2003 server without having your application using the latest
   Advantage client libraries. However, if an application is not using
   the latest Advantage client libraries, new features in the client
   will not be available to your application. Also, new features in the
   Advantage Database Server may not be available to your application.
   If the version of the Advantage Database Server is older than the
   version of the Advantage client libraries used by your application,
   either an "Advantage Client incompatible with Advantage Server"
   error or an "Advantage Server not available" error will result.
   The ADSVER.EXE utility supplied in your Advantage directory can
   be used to determine the version of the Advantage Database Server
   executable, ADS.EXE, and the Advantage Client libraries used by
   your application.

*  The Advantage Database Server for Windows NT/2000/2003 also supports
   the Windows XP operating system. But since Windows XP is designed to
   be a desktop operating system, "XP" has not been added to the name
   of the Advantage Database Server for Windows NT/2000/2003 product.


4. What's New in v8.1
============================

*  It is now possible to define vertical filters on replicated tables
   to control which columns of data are replicated.  This gives
   greater control over the replication process and allows for more
   flexible scenarios.  For example, vertical filters make it
   possible to replicate to a target table that has fewer columns
   than the source table.

*  Added the Advantage installation path to the Advantage
   Configuration Utility.  See the "File Locations" tab on the
   "Configuration Utility" tab.

*  Added a server configuration parameter called PERMITTED_REP_ERRORS
   to allow customization of the types of errors that are allowed
   during replication to a target when the "Ignore Replication
   Failures" options is turned on for a subscription.

*  It is now possible to use TCP/IP to communicate with the Advantage
   Database Server from all ACE based clients and ADSDOSIP.


*  Enhancements associated with the SQL engine:

  * Added TOP support for subqueries.

  * Added support for defining user defined functions (UDFs) in the
    database using SQL scripting.  User defined functions can be used
    just like existing SQL scalar functions.  UDFs allow the developer
    to extend the functionality of the SQL engine.  UDFs can be put
    into packages to avoid name conflicts.

  * SQL script now supports NOT FETCH as a condition in IF and
    WHILE statements.

  * Added a scalar function called NEWIDSTRING which can be used to
    generate a GUID on Windows operating systems.


*  Miscellaneous enhancements:

  * Several Advantage Management API functions now return the IP
    address of the Terminal Services client for any Advantage
    connection originating from a Windows Terminal Services session.
    Note: This information is only available from 7.1 and newer
    Advantage Clients.

  * Indexes created on dictionary-bound tables can now have a custom
    index description stored in the data dictionary.

  * Multiple triggers can now be created with the same
    name.  Trigger names only need to be unique on a per-table basis.

  * Added support of the Numeric field type to ADT tables.  The
    Numeric field type can be use to store exact numeric values with
    up to 30 digits of precision.

  * Performance has been improved for many types of SQL statements.
    SQL statements that require temporary storage files will now make
    use of the cache system.  Depending on the amount of cache memory
    available and the size of the result set, many queries will no
    longer use the hard drive for temporary storage.

  * Performance of triggers implemented as SQL scripts has been
    improved.

  * Added an expression engine function called NEWIDSTRING which can be
    used to generate a GUID on Windows operating systems.


5. What's New in v8.0
============================

The following is a list of significant new features and enhancements
in Advantage Database Server v8.0. If the feature/enhancement also
requires the 8.0 version of an Advantage client in order to be
available, it is specifically noted.

*  New functionality specific to the Advantage Database Server:

  * Added replication support to Advantage Database Server.
    Replication provides the capability to distribute changes from
    tables in one database to tables in another database.

  * Added online backup support.  Online Backup (or "hot" backup)
    functionality allows you to capture and save a snapshot of your
    database.  If users currently have tables opened and are making
    changes, the resulting backup image will not include their new
    modifications, it will only include the data as it existed when
    the snapshot was taken.

  * Added support for Network Attached Storage (NAS) devices.

  * Added a language configuration tab to the Advantage Database
    Server Configuration Utility (ADS_CFG.EXE).

  * Added caching functionality for AEP and trigger DLL containers.
    The new functionality allows you to update the DLL while it is
    actively being used.

  * Added new index file caching mechanism to provide faster index
    file access.  Frequently used index pages are cached for faster
    seeks and reads.  By default, the Advantage Database Server will
    use no more than half the available system memory (RAM) for
    caching.  This value can be adjusted using the MAX_CACHE_MEMORY
    configuration setting.

  * Improved the user interface of ADSSTAMP.EXE.  ADSSTAMP.EXE is an
    an important Advantage Database Server deployment utility.  The
    improvements to its user interface and overall operation will
    improve the process for upgrading server versions, expanding
    user counts, and most importantly, improve the installation of
    Service Updates.

  * All communication with the Advantage Database Server can now be
    encrypted when using dictionary connections and version 8.0 or
    greater clients.  In versions prior to 8.0, communication
    encryption was limited to internet connections to the Advantage
    Database Server.

  * Improved performance of large transactions.

  * Added support for transaction savepoints.

  * Added support for logging errors to an ADT table.  The default
    behavior now is to log to ads_err.adt.  If it is not possible to
    use this file, Advantage will revert to logging to the
    ads_err.dbf file.  The server configuration parameter
    ERROR_LOG_TYPE can be used to control which log file to use.

  * Added server-side alias support.  Server-side aliases allow you
    to hide the path to your data, as well as remove all Windows
    shares and still connect to your Advantage data.


*  New Advantage functionality associated with the SQL engine:

  * Added support for an SQL scripting language.  The scripting
    language supports flow control statements as well as cursors.
    SQL scripts can be used to implement trigger and stored
    procedures.  They may also be executed directly as a single SQL
    statement.

  * SQL scripts now allow different numbers and different types of
    parameters for the statements in the script.  For example, the
    following script is now allowed: UPDATE customer SET name = ?  WHERE
    id = 1; SELECT * FROM customer WHERE id = 1; See the "Effect of
    Upgrading" section for implications for existing programs that
    expect the old behavior.

  * When executing an SQL script, if the last statement in the
    script is a "SELECT ..." statement, a cursor will be returned.
    This change makes using temporary data that is populated using
    SQL scripts more convenient.  For example, the following script
    can be used to return a cursor as the final result: SELECT
    DISTINCT name INTO #temp FROM customer; SELECT Count(*) As "Number
    of Distinct Names" FROM #temp; See the "Effect of Upgrading"
    section for implications for existing programs that expect the
    old behavior.

  * Added ESCAPE character functionality to the SQL LIKE operator.
    Also updated table names operator to allow expressions for both of
    its arguments.

  * Added support for subqueries anywhere an expression is allowed.

  * Added support for alias column names in the HAVING clause.

  * Added support for FULL [OUTER] JOIN and RIGHT [OUTER] JOIN
    syntax.

  * Enhanced parameter support in the SQL statement.  Now parameters
    may be used as arguments to most scalar functions.  For the
    scalar functions that cannot take parameters as arguments due to
    unknown data types for the specific arguments, the parameter may
    be cast to a specific data type.

  * All queries executed can now be logged to a table to help with
    query optimization during application development.

  * Improved execution efficiency of SQL scripts.  With large SQL
    scripts, i.e.  a SQL script with many lines, the performance
    improvement is very significant.  Internal testing comparing
    v7.1 with v8.0 has shown that with a 80000 line script, the
    execution time is reduced from well over 30 minutes to less than
    one minute.

  * After executing an SQL script with multiple DML statements, the
    cumulative number of rows modified by all DML statements in the
    script can now be retrieved.


*  Miscellaneous new functionality:

  * AFTER triggers can now be used to update the same record that
    caused the trigger to fire.  This operation would create a
    locking error in previous versions of Advantage.  INSTEAD OF
    triggers are no longer required to update the same record that
    caused the trigger to fire, resulting in much simpler trigger
    statements.  For example, if you want to maintain a specific
    field after each update to a record, you no longer have to write
    an INSTEAD OF trigger and worry about posting changes to all
    fields.  The same functionality can now be implemented with a
    simple AFTER trigger that only modifies the field in question.

  * Indexes on dictionary-bound ADT tables can now be encrypted
    providing enhanced security, but a version 8.0 or greater client
    is required to open those tables.

  * Improved performance of filtered record count operations.

  * Improved the performance of ALTER TABLE and AdsRestructureTable.
    The overhead associated with altering tables in data
    dictionaries has been reduced resulting in faster alter
    operations.

  * Added client user login name to the management APIs.  The client
    user login name is the user name credential provided by the user
    when logging into the client PC.

  * A new per-application setting called ApplicationID was added.
    This new identifier is initialized to the application (.exe)
    name and configurable via the sp_SetApplicationID and
    sp_GetApplicationID system procedures.  The application
    identifier can be used, for example, to uniquely identify
    applications modifying a database when your product has many
    different interfaces.

  * Added the ability to disable triggers.

  * Added two new ADT field types.  ADS_ROWVERSION is an integer
    type automatically incremented each time a record is updated.
    The rowversion value is unique to the entire table.  ADS_MODTIME
    is a timestamp field automatically updated with the current
    date/time when a record is updated. This feature requires an
    8.0 or greater Advantage client.

  * Added support for DBF tables and associated memo files (FPT/DBT)
    that exceed 4 gigabytes in size.

  * Improved logic for handling index page sizes when creating new
    indexes in an ADI index file.  When a new index order is created
    that requires a larger page size than is used in an existing
    index file, Advantage will attempt to rebuild the index with an
    appropriate index page size.  This should eliminate the
    possibility of 5188 errors. This feature requires an
    8.0 or greater Advantage client.

  * When adding a DBF table to a data dictionary, it is no longer
    required to have exclusive access to the table unless the table
    will be encrypted when it is added.


6. Known Problems
============================

*  If your data files are located on a drive using NTFS, that PC's
   "system" group must have full access to the share which contains
   the data in order for the Advantage Database Server service to have
   access to that data. Note: It must be that PC's system group that
   has full access, not the domain's system group.

*  The Advantage "rights checking" functionality is not fully
   supported with free connections. If Advantage "check rights"
   security is being used (the default is to check rights with free
   connections), and a user has READ access rights ONLY to a shared
   directory, Advantage will allow that user full read and write access
   to files in that directory. If the user does not have any access
   rights to the shared directory where the tables are located,
   Advantage rights checking functionality will work as expected.
